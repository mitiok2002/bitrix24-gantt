# Bitrix24 Gantt Diagram

Веб-приложение для отображения задач Bitrix24 в виде диаграммы Ганта с организационной структурой.

## 🎯 Возможности

- 📊 **Диаграмма Ганта** с задачами из Bitrix24
- 🏢 **Организационная структура** - дерево подразделений и сотрудников
- 🔍 **Фильтрация** - по датам, подразделениям, сотрудникам, статусам
- 🔎 **Поиск** по названию задачи
- 📅 **Масштабирование** - день, неделя, месяц
- 🌳 **Сворачивание/разворачивание** подразделений
- ⚡ **Быстрые фильтры** - неделя, месяц, квартал

## 🏗 Структура проекта

```
/
├── backend/          # Node.js/Express API
│   ├── src/         # Исходный код
│   │   ├── routes/  # API routes (auth, tasks, users, departments)
│   │   └── index.ts # Entry point
│   └── api/         # Vercel serverless functions
├── frontend/        # React приложение
│   ├── src/
│   │   ├── components/  # React компоненты
│   │   ├── hooks/       # Custom hooks
│   │   ├── stores/      # Zustand stores
│   │   ├── types/       # TypeScript types
│   │   ├── utils/       # Утилиты трансформации данных
│   │   └── api/         # API клиент
│   └── dist/        # Build output
├── docs/            # Документация проекта
└── vercel.json      # Конфигурация деплоя
```

## 🚀 Быстрый старт

Подробные инструкции:
- [QUICKSTART.md](./docs/QUICKSTART.md) - Быстрый старт за 5 минут
- [SETUP.md](./docs/SETUP.md) - Локальная разработка
- [DEPLOYMENT.md](./docs/DEPLOYMENT.md) - Деплой на Vercel

### Краткая версия

**Способ 1: Одной командой (рекомендуется)**
```bash
# Установка всех зависимостей
npm run install:all

# Настройка .env файлов
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
# Отредактируйте .env файлы - добавьте CLIENT_ID и CLIENT_SECRET из Bitrix24

# Запуск обоих серверов одновременно
npm run dev
```

**Способ 2: Раздельный запуск**

1. **Backend**
```bash
cd backend
npm install
cp .env.example .env
# Отредактируйте .env - добавьте CLIENT_ID и CLIENT_SECRET из Bitrix24
npm run dev
```

2. **Frontend** (в новом терминале)
```bash
cd frontend
npm install --legacy-peer-deps
cp .env.example .env
# Отредактируйте .env
npm run dev
```

3. Откройте `http://localhost:5173`

## 🔧 Технологии

### Frontend
- **React 19** + **TypeScript**
- **Vite** - быстрая сборка
- **Ant Design** - UI компоненты
- **gantt-task-react** - Gantt диаграмма
- **Zustand** - state management
- **React Query** - кеширование данных
- **React Router** - роутинг
- **Axios** - HTTP клиент
- **Day.js** - работа с датами

### Backend
- **Node.js** + **Express** + **TypeScript**
- **Axios** - запросы к Bitrix24 API
- **CORS** - настроена безопасность
- **OAuth 2.0** - авторизация через Bitrix24

## 📋 Требования Bitrix24

Приложение требует доступа к следующим методам Bitrix24 REST API:
- `tasks.task.list` - получение задач
- `department.get` - структура подразделений  
- `user.get` - список пользователей

## 🌐 Деплой

Приложение готово к деплою на Vercel:

```bash
# Через CLI
vercel

# Или через GitHub integration
```

См. [DEPLOYMENT.md](./docs/DEPLOYMENT.md) для подробностей.

## 📚 Документация

Вся документация находится в директории [docs/](./docs/):

| Документ | Описание |
|----------|----------|
| [QUICKSTART.md](./docs/QUICKSTART.md) | Быстрый старт за 5 минут |
| [SETUP.md](./docs/SETUP.md) | Детальная инструкция по локальной разработке |
| [DEPLOYMENT.md](./docs/DEPLOYMENT.md) | Инструкция по деплою на Vercel |
| [API_EXAMPLES.md](./docs/API_EXAMPLES.md) | Примеры использования API |
| [PROJECT_STRUCTURE.md](./docs/PROJECT_STRUCTURE.md) | Полная структура проекта |
| [PROJECT_SUMMARY.md](./docs/PROJECT_SUMMARY.md) | Резюме и статистика проекта |
| [CONTRIBUTING.md](./docs/CONTRIBUTING.md) | Руководство для контрибьюторов |
| [CHANGELOG.md](./docs/CHANGELOG.md) | История изменений |
| [STATUS.md](./docs/STATUS.md) | Текущий статус проекта |

## 📝 Лицензия

ISC

## 🤝 Контакты

Для вопросов и предложений создайте issue в репозитории.

