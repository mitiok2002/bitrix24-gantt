# Quick Start Guide

Быстрый старт для разработчиков. За 5 минут от клонирования до работающего приложения.

## Шаг 1: Требования

Убедитесь что установлено:
- ✅ Node.js 18+ (`node --version`)
- ✅ npm или yarn
- ✅ Аккаунт Bitrix24

## Шаг 2: Клонирование

```bash
git clone <your-repo-url>
cd GantDiagram
```

## Шаг 3: Получение Bitrix24 credentials

1. Откройте ваш Bitrix24: `https://your-domain.bitrix24.ru`
2. **Приложения** → **Разработчикам** → **Другое** → **Локальное приложение**
3. Создайте новое приложение
4. Скопируйте:
   - `CLIENT_ID` (например: local.65f8a1b2c3d4e5.12345678)
   - `CLIENT_SECRET` (например: A1B2C3D4E5F6...)
5. Установите **Redirect URI**: `http://localhost:5173/auth/callback`
6. Сохраните приложение

## Шаг 4: Установка зависимостей

```bash
npm run install:all
```

⏳ Это займет 2-3 минуты

## Шаг 5: Конфигурация

### Backend

```bash
cp backend/.env.example backend/.env
```

Откройте `backend/.env` и вставьте:
```env
PORT=3001
BITRIX24_CLIENT_ID=ваш_client_id_из_шага_3
BITRIX24_CLIENT_SECRET=ваш_client_secret_из_шага_3
BITRIX24_REDIRECT_URI=http://localhost:5173/auth/callback
FRONTEND_URL=http://localhost:5173
```

### Frontend

```bash
cp frontend/.env.example frontend/.env
```

Откройте `frontend/.env` и вставьте:
```env
VITE_API_URL=http://localhost:3001
VITE_BITRIX24_CLIENT_ID=ваш_client_id_из_шага_3
```

## Шаг 6: Запуск

```bash
npm run dev
```

Это запустит:
- 🔧 Backend на `http://localhost:3001`
- 🌐 Frontend на `http://localhost:5173`

## Шаг 7: Использование

1. Откройте браузер: `http://localhost:5173`
2. Введите домен Bitrix24: `your-domain.bitrix24.ru` (без https://)
3. Нажмите "Войти через Bitrix24"
4. В открывшемся окне авторизуйтесь
5. Готово! 🎉

## Проверка работы

После авторизации вы должны увидеть:
- ✅ Диаграмму Ганта с задачами
- ✅ Дерево подразделений слева
- ✅ Панель фильтров
- ✅ Переключатель режимов (День/Неделя/Месяц)

## Troubleshooting

### ❌ "Domain is required"
→ Введите домен без `https://` и без `/`
→ Правильно: `example.bitrix24.ru`
→ Неправильно: `https://example.bitrix24.ru/`

### ❌ "Authentication failed"
→ Проверьте CLIENT_ID и CLIENT_SECRET в .env
→ Убедитесь что redirect URI совпадает в Bitrix24 и в .env

### ❌ "CORS error"
→ Проверьте FRONTEND_URL в backend/.env
→ Перезапустите backend после изменения .env

### ❌ "Не отображаются задачи"
→ Проверьте что в Bitrix24 есть задачи с датами
→ Проверьте права приложения (tasks, user, department)
→ Откройте консоль браузера (F12) для деталей ошибки

### ❌ "Port 3001 already in use"
→ Измените PORT в backend/.env на другой (например, 3002)
→ Обновите VITE_API_URL в frontend/.env

## Дальнейшие шаги

### Документация
- 📖 [README.md](../README.md) - обзор проекта
- 🛠 [SETUP.md](./SETUP.md) - детальная инструкция по разработке
- 🌐 [DEPLOYMENT.md](./DEPLOYMENT.md) - деплой на Vercel
- 📡 [API_EXAMPLES.md](./API_EXAMPLES.md) - примеры API

### Разработка
- 🏗 [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) - структура проекта
- 🤝 [CONTRIBUTING.md](./CONTRIBUTING.md) - как контрибьютить
- 📝 [CHANGELOG.md](./CHANGELOG.md) - история изменений

## Полезные команды

```bash
# Запуск обоих серверов
npm run dev

# Только backend
npm run dev:backend

# Только frontend
npm run dev:frontend

# Build для продакшена
npm run build

# Установка всех зависимостей
npm run install:all
```

## Что дальше?

### Попробуйте фильтры:
1. 🔍 Поиск по названию задачи
2. 📅 Фильтр по датам (или используйте быстрые: Неделя, Месяц, Квартал)
3. 🏢 Фильтр по подразделениям
4. 👤 Фильтр по сотрудникам
5. 📊 Фильтр по статусам

### Попробуйте режимы отображения:
- 📅 **День** - детальный вид с почасовыми интервалами
- 📆 **Неделя** - недельный вид
- 📊 **Месяц** - месячный обзор

### Сверните подразделение:
- Нажмите на стрелку рядом с названием подразделения
- Все сотрудники и их задачи свернутся

## Нужна помощь?

- 🐛 Нашли баг? Создайте [Issue](https://github.com/...)
- 💡 Есть идея? Создайте [Feature Request](https://github.com/...)
- ❓ Вопрос? Проверьте [SETUP.md](./SETUP.md)

Удачи! 🚀

