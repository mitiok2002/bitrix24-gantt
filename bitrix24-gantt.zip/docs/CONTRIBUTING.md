# Contributing Guide

Спасибо за интерес к проекту! Это руководство поможет вам начать работу.

## Процесс разработки

### 1. Форк репозитория

```bash
# Форкните репозиторий на GitHub
# Затем клонируйте свой форк
git clone https://github.com/YOUR_USERNAME/GantDiagram.git
cd GantDiagram
```

### 2. Установка зависимостей

```bash
npm run install:all
```

### 3. Настройка окружения

```bash
# Скопируйте примеры .env файлов
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# Отредактируйте файлы, добавьте свои CLIENT_ID и CLIENT_SECRET
```

### 4. Запуск в режиме разработки

```bash
npm run dev
```

## Структура проекта

```
/
├── backend/              # Node.js API
│   ├── src/
│   │   ├── routes/      # API маршруты
│   │   │   ├── auth.ts  # OAuth авторизация
│   │   │   └── api.ts   # Data endpoints
│   │   └── index.ts     # Entry point
│   └── api/             # Vercel serverless
├── frontend/            # React приложение
│   ├── src/
│   │   ├── components/  # React компоненты
│   │   ├── hooks/       # Custom hooks
│   │   ├── stores/      # Zustand stores
│   │   ├── types/       # TypeScript типы
│   │   ├── utils/       # Утилиты
│   │   └── api/         # API клиент
│   └── public/
└── docs/                # Документация
```

## Стандарты кода

### TypeScript

- Используйте строгую типизацию
- Избегайте `any`, используйте `unknown` если тип неизвестен
- Создавайте интерфейсы для всех сложных объектов

### React

- Функциональные компоненты с хуками
- Используйте `memo` для оптимизации
- Разделяйте логику и представление

### Именование

- **Компоненты**: PascalCase (например, `GanttChart.tsx`)
- **Файлы утилит**: camelCase (например, `dataTransform.ts`)
- **Константы**: UPPER_SNAKE_CASE
- **Переменные/функции**: camelCase

### Комментарии

```typescript
// Хорошо: пояснение сложной логики
// Вычисляем критический путь для задач с зависимостями
const criticalPath = calculateCriticalPath(tasks, dependencies);

// Плохо: очевидный комментарий
// Создаем переменную
const result = getData();
```

## Процесс отправки изменений

### 1. Создайте ветку

```bash
git checkout -b feature/your-feature-name
# или
git checkout -b fix/bug-description
```

### 2. Делайте коммиты

Используйте conventional commits:

```bash
git commit -m "feat: добавлена фильтрация по статусам"
git commit -m "fix: исправлена ошибка с датами"
git commit -m "docs: обновлена документация API"
```

Типы коммитов:
- `feat`: новая функциональность
- `fix`: исправление бага
- `docs`: изменения в документации
- `style`: форматирование кода
- `refactor`: рефакторинг
- `test`: добавление тестов
- `chore`: рутинные задачи

### 3. Проверьте код

```bash
# Backend
cd backend
npm run build

# Frontend
cd frontend
npm run build
npm run lint
```

### 4. Отправьте Pull Request

1. Push в свой форк
2. Откройте PR в основной репозиторий
3. Опишите изменения
4. Дождитесь ревью

## Что можно улучшить

### High Priority
- [ ] Добавить unit тесты
- [ ] Добавить интеграционные тесты
- [ ] Улучшить обработку ошибок
- [ ] Добавить retry логику для API запросов

### Medium Priority
- [ ] Добавить prettier конфигурацию
- [ ] Создать storybook для компонентов
- [ ] Добавить E2E тесты с Playwright
- [ ] Оптимизировать bundle size

### Low Priority
- [ ] Добавить GitHub Actions CI/CD
- [ ] Настроить автоматический линтинг в pre-commit
- [ ] Добавить code coverage badges
- [ ] Создать Docker контейнеры

## Вопросы?

Если у вас есть вопросы:
1. Проверьте существующие Issues
2. Прочитайте документацию
3. Создайте новый Issue с меткой "question"

## Код поведения

- Будьте уважительны к другим участникам
- Конструктивная критика приветствуется
- Помогайте новичкам
- Следуйте принципам open source

Спасибо за ваш вклад! 🎉

